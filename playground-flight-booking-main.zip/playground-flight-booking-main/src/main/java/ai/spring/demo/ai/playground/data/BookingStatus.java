package ai.spring.demo.ai.playground.data;

public enum BookingStatus {
    CONFIRMED, COMPLETED, CANCELLED
}
