@NonNullApi
package ai.spring.demo.ai.playground.client;

import org.springframework.lang.NonNullApi;
