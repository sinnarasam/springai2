package ai.spring.demo.ai.playground.data;

public enum BookingClass {
    ECONOMY, PREMIUM_ECONOMY, BUSINESS
}
