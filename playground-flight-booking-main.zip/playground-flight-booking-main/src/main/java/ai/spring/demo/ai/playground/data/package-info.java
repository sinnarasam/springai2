@NonNullApi
package ai.spring.demo.ai.playground.data;

import org.springframework.lang.NonNullApi;
