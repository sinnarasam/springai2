package dev.danvega.streaming;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StreamingApplicationTests {

	@Test
	void contextLoads() {
	}

}
